-- fiusen secure - v2
return(function(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, ba, bb, bc, bd, be, bf, bg, bh, bi, bj, bk, bl, bm, bn, bo, bp, bq, br, bs, bt, bu, bv, bw, bx, by, bz, ca, cb, cc, cd, ce, cf, cg, ch, ci, cj, ck, cl, cm, cn, co, cp, cq, cr, cs, ct, cu, cv, cw, cx, cy, cz, da, db, dc, dd, de, df, dg, dh, di, dj, dk, dl, dm, dn, _do, dp, dq, dr, ds, dt, du, dv)
    local dw = a['JI@?7>N[SZ�M:']
    local dx = 3.3291057413758978;
    local dy = 247;
    local dz = dw[('\100' .. '\101') .. '\98' .. '\117' .. '\103'];
    local ea = dw[(('\116' .. '\97' .. '\98') .. '\108' .. '\101')];
    local ec = a[0 + ('' .. (function(eb)
        return(20784 * eb) + ((667883 + 329))
    end)(('').len 'QNCH\0KYSVL'))];
    local ed = ec[(('\99' .. '\104') .. '\97' .. '\114')];
    local ee = 6;
    local ef = dw[ed((0.2286282306163022 * 503), tonumber('' .. ee ^ 2.5757478032637917), (0 + (('' .. (9 ^ 2.1309297535714573)))), tonumber(('' .. 4 ^ dx)), (990 / 10), 1029 - 913)];
    local eg = ec[ed(87091 / 799, (-632 + 729), -576 + 692, tonumber('' .. 7 ^ 2.361424473974503), dy - 143)];
    local eh = ed((0.3673469387755102 * 294), 91180 / 940, (-644 + 759), 13456 ^ 0.5, (159 - 51), tonumber('' .. (4 ^ 3.357122758833061)), tonumber(('' .. 2 ^ 6.78135971352466)), 0.43722943722943725 * 231, 27300 / 273, (604 - 503), 10404 ^ 0.5, (7 ^ 2.3916625094004957), 12100 ^ 0.5, (2.525 * 40), (10000 ^ 0.5))
    local ei = '\?\E\%\C\=\O';
    local ej = '\^\>\Q\0\B\+';
    local ek = ea[ed(tonumber('' .. 2 ^ 6.6293566200796095), 322 - 211, 63470 / 577, (-202 + 301), (9409 ^ 0.5), 56724 / 489)];
    local el = a['CVZD&68^F~E*X'];
    local em = v;
    local en = a[680954];
    local eo = a['\5\Y\I\O\D\7'];
    local ep = dw[ed(tonumber(('' .. 2 ^ 6.857980995127572)), tonumber(('' .. (4 ^ 3.397207933175053))), -187 + 297, -485 + 602, tonumber('' .. 0.5190476190476191 * 210), 0.4827586206896552 * 203, (-745 + 846), (1089 - 975))];
    local eq = ea[((((('\105' .. '\110') .. '\115') .. '\101') .. '\114') .. '\116')];
    local er = ec['\115\117\98'];
    local es = ed((2.914285714285714 * 35), (905 - 788), 1102 - 992, (0.12147239263803682 * 815))
    local et = dz[ed(tonumber(('' .. 4 ^ 3.3432502635916093)), (315 - 214), (0.11934156378600823 * 972), (663 - 546), (12992 / 116), (362 - 244), 496 - 399, 313 - 205, (13689 ^ 0.5), 20806 / 206)]
    local eu = ed((-512 + 629));
    local ev = a['TQMCYLZ'];
    local ew = a['USVDAXH'];
    local ex = a[355600];
    local ey = dw[ed((31752 / 294), 1.7903225806451613 * 62, (9409 ^ 0.5), (0 + ('' .. 0.145985401459854 * 685)))];
    local ez = dw[ed(-260 + 375, 864 - 763, (0 + (('' .. 3 ^ 4.326904259253577))), (92977 / 853), (10201 ^ 0.5), 1.4871794871794872 * 78, 9409 ^ 0.5, 71920 / 620, (-342 + 439), 9604 ^ 0.5, (69336 / 642), tonumber(('' .. (7 ^ 2.3717027834413504))))];
    local fa = dw[('\109' .. '\97' .. '\116' .. '\104')][ed(11664 ^ 0.5, (1.1764705882352942 * 85), (10201 ^ 0.5), 60120 / 501, (0.3446153846153846 * 325))];
    local fb = ed((71820 / 665), (0 + ('' .. 9 ^ 2.1181086349396745)), 81070 / 737, (93829 / 929), (0.24330900243309003 * 411), 0.3126934984520124 * 323, (10404 ^ 0.5), (967 - 862), 104610 / 951, 58883 / 583, (0.390625 * 256))
    local fc = dz[ed(0 + (('' .. (7 ^ 2.3817795443842416))), (-49 + 150), 200 - 84, 11025 ^ 0.5, (902 - 792), 4.636363636363637 * 22, (55722 / 502))]
    local fd = ed((12100 ^ 0.5), tonumber(('' .. 7 ^ 2.447273291169)), 64176 / 573, (13225 ^ 0.5));
    local fe = ec[ed(316 - 218, (-2 + 123), 910 - 794, (0 + ('' .. (2 ^ 6.6582114827517955))))];
    local ff = ec[ed((0 + ('' .. 6 ^ 2.613147192765459)), (-452 + 553), (92950 / 845))];
    local fg = (dw[ed((-826 + 943), tonumber('' .. (2 ^ 6.78135971352466)), 58352 / 521, 75272 / 776, 9801 ^ 0.5, 11449 ^ 0.5)] or ea[(('\117' .. '\110' .. '\112' .. '\97') .. '\99' .. '\107')]);
    local fh = dw[ed((0 + ('' .. (9 ^ 2.1474813817236256))), 938 - 839, (55096 / 568), (11664 ^ 0.5), (83700 / 775))];
    local fi = dw[ed(53136 / 492, tonumber('' .. (0.3153409090909091 * 352)), (-512 + 609), (0 + ('' .. 6 ^ 2.570194417876938)), 36340 / 316, 14616 / 126, (28158 / 247), tonumber('' .. (4 ^ 3.357122758833061)), -379 + 489, 0.14507042253521127 * 710)];
    local fj = ed(0 + ('' .. (9 ^ 2.091329169322069)), (0 + (('' .. (2 ^ 6.870364719583405)))), (26448 / 232), tonumber('' .. 2 ^ 6.832890014164742), (-839 + 940), 78430 / 713, (13456 ^ 0.5), (94176 / 872), (0.11758118701007839 * 893), 0.19927536231884058 * 552, 93526 / 926)
    local fk;
    fk = function(fl)
        local fm, fn, fo, fp, fq, fr, fs, ft, fu, fv;
        local fw = 0
        local fx = 5;
        local fy = 2;
        local fz = 4;
        while true do
            fw = fw + 1
            if (fw > 6 or fw == 6) then
                if (fw == 8 or fw < 8) then
                    if (fw == 7 or fw > 7) then
                        if not(fw ~= 7) then
                            fm = ed(ft())
                        else
                            fu[(#fu + 1)] = fm;
                        end
                    else
                        ft = function()
                            local ga, gb;
                            local gc = 0
                            while true do
                                gc = gc + 1
                                if (gc > fz or gc == fz) then
                                    if (gc > 5 or gc == 5) then
                                        if gc < ee then
                                            return gb
                                        else
                                            break
                                        end
                                    else
                                        fs = fs + ga;
                                    end
                                else
                                    if (gc == 1 or gc < 1) then
                                        ga = ep(er(fl, fs, fs), dj[2])
                                    else
                                        if not(gc ~= 2) then
                                            fs = (fs + 1);
                                        else
                                            gb = ep(er(fl, fs, fs + ga - 1), cq(dj[fy], 0))
                                        end
                                    end
                                end
                            end
                        end
                    end
                else
                    if (fw == 9 or fw < 9) then
                        local gd = 1;
                        while (fs < #fl) do
                            local ge;
                            local gf = 0
                            while true do
                                gf = (gf + 1)
                                if (gf == 4 or gf > 4) then
                                    if (gf > fx or gf == fx) then
                                        if (gf < 6) then
                                            fm, fq = fn, (fq + gd)
                                        else
                                            break
                                        end
                                    else
                                        fu[(#fu + 1)] = fn;
                                    end
                                else
                                    if (gf < 1 or gf == 1) then
                                        ge = ft()
                                    else
                                        if (gf > 2) then
                                            fr[fq] = fm .. er(fn, 1, 1)
                                        else
                                            if fr[ge] then
                                                fn = fr[ge]
                                            else
                                                fn = (fm .. er(fm, gd, gd))
                                            end;
                                        end
                                    end
                                end
                            end
                        end;
                    else
                        if (fw < 11) then
                            return ek(fu)
                        else
                            break
                        end
                    end
                end
            else
                if (fw == 3 or fw > 3) then
                    if (fw == 4 or fw > 4) then
                        if (fw > 4) then
                            fs = 1
                        else
                            for gg = 0, fq - 1 do
                                fr[gg] = ed(gg)
                            end;
                        end
                    else
                        fr = ew()
                    end
                else
                    if not(fw ~= 2) then
                        fq = dj[1]
                    else
                        fm, fn, fo, fu = ec, ec, ew(), ew()
                    end
                end
            end
        end
    end
    local gh = fk(n);
    local gi;
    gi = function(gj)
        local gk = 0
        while true do
            gk = (gk + 1)
            if not(gk ~= 1) then
                return(ec .. gj)
            else
                break
            end
        end
    end
    local gl = 0;
    local gm;
    gm = function()
        local gn = 0
        local go = 1;
        while true do
            gn = gn + go
            if gn > 1 then
                break
            else
                gl = gl + 1
            end
        end
    end
    local gp;
    gp = function(gq, gr)
        local gs, gt, gu, gv, gw;
        local gx = 0
        while true do
            gx = gx + 1
            if (gx > 4 or gx == 4) then
                if (gx < 4 or gx == 4) then
                    local gy = 2;
                    local gz = 3;
                    while (gq > 0) do
                        local ha = 0;
                        local hb;
                        local hc = ha
                        while true do
                            hc = (hc + 1)
                            if (hc == gz or hc > gz) then
                                if not(hc ~= 3) then
                                    gq, gs = ((gq - hb) / gy), (gs * 2)
                                else
                                    break
                                end
                            else
                                if (hc < gy) then
                                    hb = gq % 2
                                else
                                    if hb > 0 then
                                        gt = gt + gs
                                    end
                                end
                            end
                        end
                    end
                else
                    if not(gx ~= 6) then
                        break
                    else
                        return gt
                    end
                end
            else
                if (gx == 1 or gx < 1) then
                    gs, gt = 1, 0
                else
                    if not(gx ~= 3) then
                        if (gq < gr) then
                            gq = gr
                        end
                    else
                        local hd = 2;
                        local he = 1;
                        while ((gq > 0) and (gr > 0)) do
                            local hf, hg;
                            local hh = 0
                            while true do
                                hh = hh + he
                                if (hh < hd or hh == hd) then
                                    if not(hh ~= 1) then
                                        hf, hg = (gq % 2), (gr % 2)
                                    else
                                        if not(hf == hg) then
                                            gt = gt + gs
                                        end
                                    end
                                else
                                    if not(hh ~= 3) then
                                        gq, gr, gs = ((gq - hf)) / hd, ((gr - hg) / hd), (gs * 2)
                                    else
                                        break
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    local hi = a[864242] or gp;
    ey(gm);
    local hj = gl - 1;
    local hk = a['\L\X\4\U\O\L'];
    local hl;
    hl = function()
        local hm, hn;
        local ho = 0
        while true do
            ho = (ho + 1)
            if (ho == 2 or ho < 2) then
                if not(ho ~= 2) then
                    hj = (hj + 2);
                else
                    hm, hn = fe(gh, hj, (hj + 2))
                end
            else
                if ho < 4 then
                    return(hi(hn, ev) * cq(dj[1], 0)) + hi(hm, ev);
                else
                    break
                end
            end
        end
    end
    local hp;
    hp = function()
        local hq;
        local hr = 0
        while true do
            hr = (hr + 1)
            if (hr == 2 or hr < 2) then
                if (hr > 1) then
                    hj = hj + 1;
                else
                    hq = hi(fe(gh, hj, hj), ev)
                end
            else
                if hr < 4 then
                    return hq;
                else
                    break
                end
            end
        end
    end
    local hs;
    hs = function(ht, hu, ...)
        local hv;
        local hw = 0
        while true do
            hw = (hw + 1)
            if (hw > 1) then
                break
            else
                for hx = 1, ht do
                    hu(...)
                end
            end
        end
    end
    local hy;
    hy = function()
        local hz, ia, ib, ic;
        local id = 0
        while true do
            id = id + 1
            if (id > 3 or id == 3) then
                if not(id ~= 3) then
                    return((((hi(ic, ev) * dj[3])) + ((hi(ib, ev) * dj[4])) + (hi(ia, ev) * cq(dj[1], 0))) + hi(hz, ev));
                else
                    break
                end
            else
                if id > 1 then
                    hj = hj + 4;
                else
                    hz, ia, ib, ic = fe(gh, hj, hj + 3)
                end
            end
        end
    end
    local ie;
    ie = function(_if)
        local ig;
        local ih = 0
        while true do
            ih = ih + 1
            if (ih == 2 or ih > 2) then
                if ih < 3 then
                    return(((ig[fb] + ig[eh])) < dj[5] and ig[es] or hy);
                else
                    break
                end
            else
                ig = fc(_if)
            end
        end
    end
    local ii = hy;
    local ij;
    ij = function(ik, il, ...)
        local im, _in;
        local io = 0
        while true do
            io = (io + 1)
            if (io < 2 or io == 2) then
                if not(io ~= 1) then
                    im = a['USVDAXH']()
                else
                    for ip = 1, ik do
                        im[ip] = ie(il)(...)
                    end
                end
            else
                if not(io ~= 4) then
                    break
                else
                    return fg(im)
                end
            end
        end
    end
    local iq;
    iq = function(ir)
        local is, it, iu;
        local iv = 0
        local iw = 2;
        local ix = 1;
        while true do
            iv = iv + ix
            if (iv == 3 or iv < 3) then
                if (iv == 1 or iv < 1) then
                    is, it = a[0 + ('' .. (function(iy)
                        return((20784 * iy) + (667883 + 329))
                    end)(ff 'QNCH\0KYSVL'))]
                else
                    if iv > iw then
                        it = er(gh, hj, (hj + ir - 1));
                    else
                        if (not ir) then
                            local iz = 0
                            local ja = 0;
                            local jb = 3;
                            while true do
                                iz = iz + 1
                                if (iz < ix or iz == ix) then
                                    ir = ii();
                                else
                                    if not(iz ~= jb) then
                                        break
                                    else
                                        if (not(ir ~= ja)) then
                                            return a[0 + ('' .. (function(jc)
                                                return(20784 * jc) + ((667883 + 329))
                                            end)(ff 'QNCH\0KYSVL'))];
                                        end;
                                    end
                                end
                            end
                        end;
                    end
                end
            else
                if (iv < 5 or iv == 5) then
                    if not(iv ~= 4) then
                        hj = (hj + ir);
                    else
                        for jd = 1, #it do
                            is = (is .. ed(hi(fe(er(it, jd, jd)), ev)))
                        end
                    end
                else
                    if (iv < 7) then
                        return is;
                    else
                        break
                    end
                end
            end
        end
    end
    local je;
    je = function()
        local jf, jg, jh, ji, jj, jk;
        local jl = 0
        local jm = 2;
        local jn = 0;
        while true do
            jl = (jl + 1)
            if (jl > 5 or jl == 5) then
                if (jl == 6 or jl < 6) then
                    if jl > 5 then
                        if (not(jj ~= 0)) then
                            if (not(ji ~= 0)) then
                                return jk * 0;
                            else
                                jj = 1;
                                jh = jn;
                            end;
                        elseif (not(jj ~= dj[6])) then
                            return((not(ji ~= 0)) and ((jk * ((1 / 0))))) or (jk * ((jn / 0)));
                        end;
                    else
                        jk = ((-1) ^ hk(jg, cq(dj[2], 4)))
                    end
                else
                    if not(jl ~= 8) then
                        break
                    else
                        return(fa(jk, jj - dj[7]) * (jh + ((ji / ((jm ^ dj[8]))))));
                    end
                end
            else
                if (jl > 3 or jl == 3) then
                    if not(jl ~= 4) then
                        jj = hk(jg, cq(dj[5], -6), cq(dj[jm], 5))
                    else
                        ji = (((hk(jg, 1, cq(dj[5], -5)) * (2 ^ cq(dj[2], 4)))) + jf)
                    end
                else
                    if (jl < 2) then
                        jf, jg = ij(2, hy)
                    else
                        jh = 1
                    end
                end
            end
        end
    end
    local jo, jp, jq, jr, js, jt, ju, jv, jw;
    a[946173] = hi;
    for jx = 47481344 / 512, (77401360521 ^ 0.5), 67605273 / 729 do
        if not(jx ~= -278 + 867) then
            jr = (function(jy)
                return(({ [jy] = 0.15514997185152601 })[0.0008088528431574194] ^ 1.413624156336542)
            end)(0.9720324310608409 ^ '251');
        elseif not(jx ~= 85410777 / 921) then
            js = hy;
        elseif not(jx ~= 129270 / 465) then
            jw = cc;
        elseif not(jx ~= 149688 / 264) then
            jw = a[539197];
        elseif not(jx ~= 104 + 348) then
            ce = 'LSAABFL';
        elseif not(jx ~= 43029968 / 232) then
            jw = a[539197];
        elseif not(jx ~= (179 + 167)) then
            l = 6.239726027397261 * 146;
        elseif not(jx ~= 488 - 331) then
            o = eg(a['\A\X\P\]\E\#'](), cy);
        elseif not(jx ~= ep(gi(9 ^ 2.722258922893526))) then
            jr = 394384 ^ 0.5;
        elseif not(jx ~= 845.6261398176292 * 329) then
            jr = eg(a['\A\X\P\]\E\#'](), cy);
        elseif not(jx ~= (833 - 543)) then
            dt = eg(a['\A\X\P\]\E\#'](), cy);
        elseif not(jx ~= 0.36419753086419754 * 324) then
            dn = hy;
        elseif not(jx ~= (-8 + 155)) then
            jr = l;
        elseif not(jx ~= 147 + 319) then
            k = k;
        end
    end
    jq = function(jz)
        local ka = 0
        local kb = 1;
        while true do
            ka = (ka + kb)
            if ka < 2 then
                return #jz;
            else
                break
            end
        end
    end
    local kc = ec;
    jt = function(kd)
        local ke;
        local kf = 0
        while true do
            kf = kf + 1
            if (kf < 1 or kf == 1) then
                local kg = 761;
                local kh = 251;
                local ki = 254;
                for kj = (220113 + 509), 0 + (gi((5 ^ 7.645033097446276))), 220368 + ki do
                    if not(kj ~= 0.9243027888446215 * kh) then
                        kc = ('"' .. '"') .. "'";
                    elseif not(kj ~= (63539136 / 288)) then
                        kc = eo(kc, en(ex(kd, a)));
                    elseif not(kj ~= -134 + 319) then
                        bf = 'D_BZZ:�TC_AT0';
                    elseif not(kj ~= 251001 ^ 0.5) then
                        kc = y;
                    elseif not(kj ~= 163) then
                        kc = eo(kc, en(ex(kd, a)));
                    elseif not(kj ~= -647 + kg) then
                        bn = bn;
                    elseif not(kj ~= 0 + (gi(3 ^ 5.37280840045705))) then
                        cr = eo(kc, en(ex(kd, a)));
                    end
                end
            else
                if kf < 3 then
                    return kc;
                else
                    break
                end
            end
        end
    end
    jp = function(kk, kl, ...)
        local km, kn;
        local ko = 0
        while true do
            ko = ko + 1
            if (ko < 2) then
                for kp, kq in next, kk do
                    kk[kp] = kl(kq, ...)
                end
            else
                break
            end
        end
    end
    jo = function(kr, ks)
        local kt;
        local ku = 0
        local kv = 4;
        local kw = 1;
        while true do
            ku = (ku + kw)
            if (ku == 2 or ku < 2) then
                if ku > 1 then
                    kc = ks;
                else
                    kt = el(kr)
                end
            else
                if (ku == kv or ku > kv) then
                    if (ku < 5) then
                        return kc;
                    else
                        break
                    end
                else
                    jp(kt, jt)
                end
            end
        end
    end
    ju = function(kx)
        local ky = 0
        while true do
            ky = (ky + 1)
            if not(ky ~= 1) then
                return kx and ((not fh(jq, kx) and kx) or jo(kx, ec))
            else
                break
            end
        end
    end
    jv = function(kz, la, ...)
        local lb, lc;
        local ld = 0
        while true do
            ld = (ld + 1)
            if ld > 1 then
                break
            else
                for le, lf in next, kz do
                    la(lf, ...)
                end
            end
        end
    end
    local lg;
    lg = function()
        local lh, li, lj, lk, ll, lm, ln, lo, lp, lq, lr, ls;
        local lt = 0
        local lu = 902;
        local lv = 2;
        local lw = 495;
        local lx = 36630;
        local ly = 332;
        local lz = 276;
        local ma = 356688;
        local mb = 917;
        local mc = 1;
        while true do
            lt = lt + 1
            if (lt < 6 or lt == 6) then
                if (lt < 3 or lt == 3) then
                    if (lt == 1 or lt < 1) then
                        lh = {
                            172225 ^ 0.5,
                            (function(md)
                                return(({ [md] = 0.6011723174052572 })[3.2842117535530423E+47] ^ 1.8385902049151075)
                            end)((1.5332432421345088 ^ '256')),
                            ['?(O,NYBM.@X=2'] = 'NGLZZFN',
                            #'KOSECZMQZBH\0_JMQBEAEUSDIH'
                        }
                    else
                        if not(lt ~= 3) then
                            lj, lk, ll = ij(3, a['USVDAXH'])
                        else
                            li = hy()
                        end
                    end
                else
                    if (lt == 5 or lt > 5) then
                        if (lt < 6) then
                            local me = 513;
                            local mf = 0.9045643153526971;
                            local mg = 572;
                            local mh = 0.6872659176029963;
                            local mi = 737;
                            local mj = 0.052917232021709636;
                            local mk = 178072;
                            local ml = 22;
                            for mm = mc, li do
                                local mn, mo;
                                local mp = 396;
                                local mq = 826;
                                local mr = 3;
                                local ms = 0
                                while true do
                                    ms = ms + 1
                                    if (ms == 3 or ms > 3) then
                                        if (ms < 3 or ms == 3) then
                                            if (not(mn ~= bl)) then
                                                mo = (not(hp() == 0));
                                            elseif (not(mn ~= cb)) then
                                                mo = iq();
                                            elseif (not(mn ~= bu)) then
                                                mo = je();
                                            end;
                                        else
                                            if not(ms ~= 4) then
                                                lm[mm] = mo;
                                            else
                                                break
                                            end
                                        end
                                    else
                                        if ms < lv then
                                            mn = (jr and hp())
                                        else
                                            mo = (function()
                                                local mt, mu = fh(hk)
                                                local mv = 4823.8378378378375;
                                                local mw = 7853208;
                                                local mx, my;
                                                while mc do
                                                    if my then
                                                        break;
                                                    end
                                                    local mz = 893;
                                                    local na = 566;
                                                    for nb = 179396 - 914, (mw / ml), (mv * 37) do
                                                        if not(nb ~= (-375 + mb)) then
                                                            my = 'ILBVVAC';
                                                        elseif not(nb ~= mk + 410) then
                                                            mx = mu;
                                                        elseif not(nb ~= (mj * mi)) then
                                                            dh = eg(mu, cy);
                                                        elseif not(nb ~= mh * 534) then
                                                            mx = mu;
                                                        elseif not(nb ~= (0 + (gi((mr ^ 5.0331032563043365))))) then
                                                            bx = ee;
                                                        elseif not(nb ~= (na - mp)) then
                                                            my = cv;
                                                        elseif not(nb ~= ma + lz) then
                                                            my = eg(mu, cy);
                                                        elseif not(nb ~= (-ly + 542)) then
                                                            dp = mu;
                                                        elseif not(nb ~= 580 - mg) then
                                                            r = r;
                                                        elseif not(nb ~= lx / lw) then
                                                            mx = di;
                                                        elseif not(nb ~= (460082 / mq)) then
                                                            dk = #'GOYOVYTYQQXPWZ\0QVFIQMTONWRZYJT';
                                                        elseif not(nb ~= (mf * 241)) then
                                                            mx = mu;
                                                        elseif not(nb ~= (-me + mz)) then
                                                            dt = '\Z\U\{\9\^\V';
                                                        end
                                                    end
                                                end
                                            end)(mm)
                                        end
                                    end
                                end
                            end;
                        else
                            lh['0?;{6CAE7/IS['] = hp();
                        end
                    else
                        lm = { }
                    end
                end
            else
                if (lt == 9 or lt < 9) then
                    if (lt == 7 or lt < 7) then
                        local nc = 619;
                        local nd = 426043;
                        local ne = 0;
                        for nf = mc, hy() do
                            local ng = 946.0354767184035;
                            local nh;
                            local ni = 2188.0102564102563;
                            local nj = 0
                            local nk = 5;
                            while true do
                                nj = nj + 1
                                if (nj == lv or nj > lv) then
                                    if nj < 3 then
                                        if (not(hk(nh, 1, mc) ~= 0)) then
                                            local nl, nm, nn;
                                            local no = ne
                                            while true do
                                                no = no + 1
                                                if (no == nk or no < nk) then
                                                    if (no < lv or no == lv) then
                                                        if no > 1 then
                                                            for np = ni * 195, ng * lu, (nd + nc) do
                                                                if not(np ~= (-111 + 674)) then
                                                                    nl = (0.912751677852349 * 596);
                                                                elseif not(np ~= (426723 - 61)) then
                                                                    nl = hk(nh, lv, 3);
                                                                elseif not(np ~= ep(gi((4 ^ 4.189689183535632)))) then
                                                                    bj = bj;
                                                                elseif not(np ~= 190969 ^ 0.5) then
                                                                    du = ('"' .. '"') .. "'";
                                                                elseif not(np ~= (1057 - 860)) then
                                                                    cm = 'PTDFM_U';
                                                                elseif not(np ~= (0 + (gi((6 ^ 3.30788039787724))))) then
                                                                    dr = 'TAWKQZS';
                                                                elseif not(np ~= 21025 ^ 0.5) then
                                                                    nl = (123172 / 212);
                                                                elseif not(np ~= (852760 + 564)) then
                                                                    nm = hk(nh, 4, 6);
                                                                elseif not(np ~= 864 - 577) then
                                                                    dp = 83.303276;
                                                                elseif not(np ~= 72361 ^ 0.5) then
                                                                    nm = dk;
                                                                elseif not(np ~= (1.7706422018348624 * 218)) then
                                                                    nl = _do;
                                                                end
                                                            end
                                                        else
                                                            nl, nm = nil
                                                        end
                                                    else
                                                        if (no < 3 or no == 3) then
                                                            nn = {
                                                                [be] = hi((hl() / (2 ^ 7)), dj[9]),
                                                                a[809455],
                                                                lh['<%>AM�EG/#R>�'],
                                                                ['\^\>\Q\0\B\+'] = hl(),
                                                            }
                                                        else
                                                            if (no < 5) then
                                                                if (not(nl ~= 0)) then
                                                                    local nq = 0
                                                                    while true do
                                                                        nq = nq + 1
                                                                        if (nq == 1 or nq < 1) then
                                                                            nn[ei] = hl();
                                                                        else
                                                                            if (nq > 2) then
                                                                                break
                                                                            else
                                                                                nn[em] = hl();
                                                                            end
                                                                        end
                                                                    end
                                                                elseif (not(nl ~= 1)) then
                                                                    nn[ei] = hy();
                                                                elseif (not(nl ~= 2)) then
                                                                    nn[ei] = (hy() - ((2 ^ cq(dj[5], -1))))
                                                                elseif (not(nl ~= 3)) then
                                                                    nn[ei] = hy() - (2 ^ cq(dj[5], -1))
                                                                    nn[em] = hl();
                                                                end;
                                                            else
                                                                if (not(nm ~= 0)) then
                                                                    nn[nl] = ju(lm[nn[ej]])
                                                                end
                                                            end
                                                        end
                                                    end
                                                else
                                                    if (no == 8 or no > 8) then
                                                        if (no > 9 or no == 9) then
                                                            if not(no ~= 10) then
                                                                break
                                                            else
                                                                lj[nf] = nn;
                                                            end
                                                        else
                                                            if (not(hk(nm, 2, 2) ~= 1)) then
                                                                nn[ei] = ju(lm[nn[ei]])
                                                            end
                                                        end
                                                    else
                                                        if no > 6 then
                                                            if (not(hk(nm, 1, 1) ~= 1)) then
                                                                nn[ej] = ju(lm[nn[ej]])
                                                            end
                                                        else
                                                            if (not(hk(nm, 3, 3) ~= 1)) then
                                                                nn[em] = ju(lm[nn[em]])
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    else
                                        break
                                    end
                                else
                                    nh = hp()
                                end
                            end
                        end;
                    else
                        if lt < 9 then
                            lh[168945] = {
                                ('"' .. '"') .. "'",
                                #'_QFSTCFXCFWG\0_KKUXXIZXGCURB',
                                [ep(gi(9 ^ 6.314459652732357))] = lj,
                                path and fmod or 121143,
                                14.588746,
                                ['<74])8.M)(+?K'] = (function(nr)
                                    return((22 * nr) + (-461))
                                end)
                            }
                        else
                            for ns = 1, hy() do
                                lk[ns - 1] = lg();
                            end;
                        end
                    end
                else
                    if (lt > 11 or lt == 11) then
                        if lt > 11 then
                            break
                        else
                            return lh;
                        end
                    else
                        lh['OZ9*ENKB6(=Y:'] = lk;
                    end
                end
            end
        end
    end
    local nt;
    nt = function(nu, nv)
        local nw, nx, ny;
        local nz = 0
        local oa = 168945;
        local ob = 72;
        local oc = 80;
        local od = 65;
        local oe = 62;
        local of = 51;
        local og = 2;
        local oh = 46;
        local oi = 44;
        local oj = 0;
        local ok = 36;
        local ol = 28;
        local om = 1;
        local on = 22;
        while true do
            nz = nz + 1
            if (nz == 3 or nz > 3) then
                if (nz == 3 or nz < 3) then
                    ny = nu['0?;{6CAE7/IS[']
                else
                    if not(nz ~= 5) then
                        break
                    else
                        return function(...)
                            local oo = 20;
                            local op = 66;
                            local oq = 1;
                            local _or = { };
                            local os = 48;
                            local ot = 67;
                            local ou = { };
                            local ov = { ... };
                            local ow = 14;
                            local ox = { };
                            local oy = 42;
                            local oz = 32;
                            local pa = ny;
                            local pb = nx;
                            local pc = 34;
                            local pd = jw;
                            local pe = (ef('#', ...) - 1);
                            local pf = 17;
                            local pg = 4;
                            local ph = 10;
                            local pi = -1;
                            local pj = 12;
                            for pk = oj, pe do
                                if ((pk == pa or pk > pa)) then
                                    ou[(pk - pa)] = ov[pk + 1];
                                else
                                    _or[pk] = ov[(pk + 1)];
                                end;
                            end;
                            local pl = ((pe - pa) + om)
                            local pm = 45;
                            local pn;
                            local po;
                            while true do
                                pn = nw[oq];
                                po = pn[be];
                                if (po < pm or po == pm) then
                                    if (po < on or po == on) then
                                        if (po < ph or po == ph) then
                                            if (po < pg or po == pg) then
                                                if (po == 1 or po < 1) then
                                                    if not(po ~= 0) then
                                                        _or[pn[ej]]();
                                                    else
                                                        _or[pn[ej]] = _or[pn[ei]] % pn[em];
                                                    end;
                                                elseif (po == 2 or po < 2) then
                                                    _or[pn[ej]][_or[pn[ei]]] = _or[pn[em]];
                                                elseif not(po ~= 3) then
                                                    local pp = pn[ej];
                                                    local pq = _or[pp];
                                                    for pr = (pp + om), pn[ei] do
                                                        eq(pq, _or[pr])
                                                    end;
                                                else
                                                    _or[pn[ej]] = nv[pn[ei]];
                                                end;
                                            elseif (po == 7 or po < 7) then
                                                if (po < 5 or po == 5) then
                                                    if not _or[pn[ej]] then
                                                        oq = oq + 1;
                                                    else
                                                        oq = pn[ei];
                                                    end;
                                                elseif not(po ~= 6) then
                                                    _or[pn[ej]] = (_or[pn[ei]] - _or[pn[em]]);
                                                else
                                                    local ps = pn[ej]
                                                    local pt, pu = pd(_or[ps](fg(_or, (ps + 1), pn[ei])))
                                                    pi = (pu + ps - 1)
                                                    local pv = 0;
                                                    for pw = ps, pi do
                                                        pv = pv + om;
                                                        _or[pw] = pt[pv];
                                                    end;
                                                end;
                                            elseif (po == 8 or po < 8) then
                                                _or[pn[ej]] = (pn[ei] * _or[pn[em]]);
                                            elseif not(po ~= 9) then
                                                do
                                                    return _or[pn[ej]]();
                                                end;
                                            else
                                                _or[pn[ej]][_or[pn[ei]]] = pn[em];
                                            end;
                                        elseif (po < 16 or po == 16) then
                                            if (po == 13 or po < 13) then
                                                if (po == 11 or po < 11) then
                                                    local px = pn[ej]
                                                    local py, pz = pd(_or[px](_or[(px + 1)]))
                                                    pi = (pz + px) - om
                                                    local qa = 0;
                                                    for qb = px, pi do
                                                        qa = qa + 1;
                                                        _or[qb] = py[qa];
                                                    end;
                                                elseif not(po ~= pj) then
                                                    if (pn[ej] < _or[pn[em]]) then
                                                        oq = pn[ei];
                                                    else
                                                        oq = oq + om;
                                                    end;
                                                else
                                                    if _or[pn[ej]] then
                                                        oq = oq + 1;
                                                    else
                                                        oq = pn[ei];
                                                    end;
                                                end;
                                            elseif (po < ow or po == ow) then
                                                _or[pn[ej]] = { };
                                            elseif not(po ~= 15) then
                                                local qc = pn[ej]
                                                _or[qc](_or[(qc + om)])
                                            else
                                                local qd = pn[ei];
                                                local qe = _or[qd]
                                                for qf = qd + 1, pn[em] do
                                                    qe = (qe .. _or[qf]);
                                                end;
                                                _or[pn[ej]] = qe;
                                            end;
                                        elseif (po < 19 or po == 19) then
                                            if (po == pf or po < pf) then
                                                _or[pn[ej]][_or[pn[ei]]] = _or[pn[em]];
                                            elseif (po > 18) then
                                                _or[pn[ej]] = pn[ei] ^ pn[em];
                                            else
                                                _or[pn[ej]] = (_or[pn[ei]] + pn[em]);
                                            end;
                                        elseif (po == oo or po < oo) then
                                            local qg = pn[ej];
                                            local qh = { };
                                            for qi = om, #ox do
                                                local qj = ox[qi];
                                                for qk = oj, #qj do
                                                    local ql = qj[qk];
                                                    local qm = ql[om];
                                                    local qn = ql[2];
                                                    if (not(qm ~= _or) and (qn == qg or qn > qg)) then
                                                        qh[qn] = qm[qn];
                                                        ql[1] = qh;
                                                    end;
                                                end;
                                            end;
                                        elseif (po > 21) then
                                            _or[pn[ej]] = (pn[ei] + _or[pn[em]]);
                                        else
                                            _or[pn[ej]] = (_or[pn[ei]] + _or[pn[em]]);
                                        end;
                                    elseif (po == 33 or po < 33) then
                                        if (po < 27 or po == 27) then
                                            if (po == 24 or po < 24) then
                                                if not(po ~= 23) then
                                                    _or[pn[ej]] = dw[pn[ei]];
                                                else
                                                    local qo = pn[ej]
                                                    local qp, qq = pd(_or[qo](_or[qo + 1]))
                                                    pi = (qq + qo) - 1
                                                    local qr = 0;
                                                    for qs = qo, pi do
                                                        qr = (qr + 1);
                                                        _or[qs] = qp[qr];
                                                    end;
                                                end;
                                            elseif (po < 25 or po == 25) then
                                                local qt = pn[ej];
                                                do
                                                    return fg(_or, qt, pi)
                                                end;
                                            elseif not(po ~= 26) then
                                                oq = pn[ei];
                                            else
                                                _or[pn[ej]][pn[ei]] = _or[pn[em]];
                                            end;
                                        elseif (po == 30 or po < 30) then
                                            if (po < ol or po == ol) then
                                                _or[pn[ej]] = _or[pn[ei]][pn[em]];
                                            elseif po > 29 then
                                                _or[pn[ej]] = _or[pn[ei]];
                                            else
                                                _or[pn[ej]] = dw[pn[ei]];
                                            end;
                                        elseif (po == 31 or po < 31) then
                                            local qu = pn[ej];
                                            local qv = _or[qu];
                                            for qw = qu + 1, pn[ei] do
                                                eq(qv, _or[qw])
                                            end;
                                        elseif (po > oz) then
                                            if _or[pn[ej]] then
                                                oq = oq + om;
                                            else
                                                oq = pn[ei];
                                            end;
                                        else
                                            if (_or[pn[ej]] < _or[pn[em]]) then
                                                oq = pn[ei];
                                            else
                                                oq = oq + om;
                                            end;
                                        end;
                                    elseif (po < 39 or po == 39) then
                                        if (po == ok or po < ok) then
                                            if (po < pc or po == pc) then
                                                local qx = pn[ej];
                                                local qy = { };
                                                for qz = 1, #ox do
                                                    local ra = ox[qz];
                                                    for rb = oj, #ra do
                                                        local rc = ra[rb];
                                                        local rd = rc[1];
                                                        local re = rc[og];
                                                        if (not(rd ~= _or) and (re > qx or re == qx)) then
                                                            qy[re] = rd[re];
                                                            rc[om] = qy;
                                                        end;
                                                    end;
                                                end;
                                            elseif (po > 35) then
                                                _or[pn[ej]] = (_or[pn[ei]] / pn[em]);
                                            else
                                                if ((pn[ej] < _or[pn[em]])) then
                                                    oq = pn[ei];
                                                else
                                                    oq = oq + 1;
                                                end;
                                            end;
                                        elseif (po < 37 or po == 37) then
                                            _or[pn[ej]][pn[ei]] = _or[pn[em]];
                                        elseif po > 38 then
                                            _or[pn[ej]] = pn[ei];
                                        else
                                            _or[pn[ej]] = _or[pn[ei]] + pn[em];
                                        end;
                                    elseif (po < oy or po == oy) then
                                        if (po < 40 or po == 40) then
                                            oq = pn[ei];
                                        elseif not(po ~= 41) then
                                            local rf = pn[ej];
                                            local rg = _or[rf + og];
                                            local rh = _or[rf] + rg;
                                            _or[rf] = rh;
                                            if ((rg > oj)) then
                                                if ((rh == _or[(rf + om)] or rh < _or[(rf + om)])) then
                                                    oq = pn[ei];
                                                    _or[(rf + 3)] = rh;
                                                end
                                            elseif ((rh == _or[rf + 1] or rh > _or[rf + 1])) then
                                                oq = pn[ei];
                                                _or[(rf + 3)] = rh;
                                            end
                                        else
                                            _or[pn[ej]] = nv[pn[ei]];
                                        end;
                                    elseif (po == 43 or po < 43) then
                                        _or[pn[ej]] = _or[pn[ei]] % pn[em];
                                    elseif (po > oi) then
                                        _or[pn[ej]] = nt(pb[pn[ei]], nil, dw);
                                    else
                                        _or[pn[ej]] = (_or[pn[ei]] * pn[em]);
                                    end;
                                elseif (po < 68 or po == 68) then
                                    if (po == 56 or po < 56) then
                                        if (po == 50 or po < 50) then
                                            if (po == 47 or po < 47) then
                                                if not(po ~= oh) then
                                                    local ri = pb[pn[ei]];
                                                    local rj;
                                                    local rk = { };
                                                    rj = ez({ }, {
                                                        __index = function(rl, rm)
                                                            local rn = rk[rm];
                                                            return rn[om][rn[og]];
                                                        end,
                                                        __newindex = function(ro, rp, rq)
                                                            local rr = rk[rp]
                                                            rr[1][rr[og]] = rq;
                                                        end;
                                                    });
                                                    for rs = 1, pn[em] do
                                                        oq = oq + 1;
                                                        local rt = nw[oq];
                                                        if not(rt[be] ~= 90) then
                                                            rk[rs - om] = {
                                                                _or,
                                                                rt[ei]
                                                            };
                                                        else
                                                            rk[rs - om] = {
                                                                nv,
                                                                rt[ei]
                                                            };
                                                        end;
                                                        ox[#ox + 1] = rk;
                                                    end;
                                                    _or[pn[ej]] = nt(ri, rj, dw);
                                                else
                                                    _or[pn[ej]] = #_or[pn[ei]];
                                                end;
                                            elseif (po == os or po < os) then
                                                local ru = pn[ej];
                                                local rv = _or[ru]
                                                local rw = _or[(ru + 2)];
                                                if (rw > 0) then
                                                    if ((rv > _or[(ru + om)])) then
                                                        oq = pn[ei];
                                                    else
                                                        _or[(ru + 3)] = rv;
                                                    end
                                                elseif ((rv < _or[(ru + 1)])) then
                                                    oq = pn[ei];
                                                else
                                                    _or[(ru + 3)] = rv;
                                                end
                                            elseif not(po ~= 49) then
                                                local rx = pn[ej];
                                                local ry = _or[rx];
                                                for rz = (rx + 1), pi do
                                                    eq(ry, _or[rz])
                                                end;
                                            else
                                                _or[pn[ej]] = (_or[pn[ei]] + _or[pn[em]]);
                                            end;
                                        elseif (po == 53 or po < 53) then
                                            if (po == of or po < of) then
                                                if (not(_or[pn[ej]] == _or[pn[em]])) then
                                                    oq = oq + 1;
                                                else
                                                    oq = pn[ei];
                                                end;
                                            elseif (po > 52) then
                                                local sa = pb[pn[ei]];
                                                local sb;
                                                local sc = { };
                                                sb = ez({ }, {
                                                    __index = function(sd, se)
                                                        local sf = sc[se];
                                                        return sf[om][sf[og]];
                                                    end,
                                                    __newindex = function(sg, sh, si)
                                                        local sj = sc[sh]
                                                        sj[1][sj[2]] = si;
                                                    end;
                                                });
                                                for sk = 1, pn[em] do
                                                    oq = oq + 1;
                                                    local sl = nw[oq];
                                                    if not(sl[be] ~= 90) then
                                                        sc[(sk - 1)] = {
                                                            _or,
                                                            sl[ei]
                                                        };
                                                    else
                                                        sc[(sk - 1)] = {
                                                            nv,
                                                            sl[ei]
                                                        };
                                                    end;
                                                    ox[#ox + 1] = sc;
                                                end;
                                                _or[pn[ej]] = nt(sa, sb, dw);
                                            else
                                                _or[pn[ej]] = { };
                                            end;
                                        elseif (po == 54 or po < 54) then
                                            _or[pn[ej]] = _or[pn[ei]] ^ pn[em];
                                        elseif po > 55 then
                                            local sm = pn[ei];
                                            local sn = _or[sm]
                                            sn = sn .. _or[sm + 1]
                                            _or[pn[ej]] = sn;
                                        else
                                            do
                                                return _or[pn[ej]]();
                                            end;
                                        end;
                                    elseif (po == oe or po < oe) then
                                        if (po == 59 or po < 59) then
                                            if (po == 57 or po < 57) then
                                                _or[pn[ej]] = pn[ei];
                                            elseif not(po ~= 58) then
                                                local so = pn[ei];
                                                local sp = _or[so]
                                                sp = (sp .. _or[(so + 1)])
                                                _or[pn[ej]] = sp;
                                            else
                                                _or[pn[ej]]();
                                            end;
                                        elseif (po < 60 or po == 60) then
                                            local sq = pn[ej];
                                            local sr = _or[sq];
                                            for ss = (sq + 1), pi do
                                                eq(sr, _or[ss])
                                            end;
                                        elseif not(po ~= 61) then
                                            local st = pn[ej]
                                            _or[st] = _or[st](fg(_or, st + 1, pi))
                                        else
                                            local su = pn[ej]
                                            _or[su] = _or[su](fg(_or, su + 1, pn[ei]))
                                        end;
                                    elseif (po < od or po == od) then
                                        if (po < 63 or po == 63) then
                                            local sv = pn[ej]
                                            _or[sv] = _or[sv](fg(_or, sv + 1, pn[ei]))
                                        elseif (po > 64) then
                                            local sw = pn[ej];
                                            local sx = _or[(sw + og)];
                                            local sy = (_or[sw] + sx);
                                            _or[sw] = sy;
                                            if ((sx > 0)) then
                                                if ((sy == _or[(sw + 1)] or sy < _or[(sw + 1)])) then
                                                    oq = pn[ei];
                                                    _or[sw + 3] = sy;
                                                end
                                            elseif ((sy == _or[sw + 1] or sy > _or[sw + 1])) then
                                                oq = pn[ei];
                                                _or[sw + 3] = sy;
                                            end
                                        else
                                            do
                                                return
                                            end;
                                        end;
                                    elseif (po < op or po == op) then
                                        _or[pn[ej]] = _or[pn[ei]] * pn[em];
                                    elseif not(po ~= ot) then
                                        do
                                            return _or[pn[ej]]
                                        end
                                    else
                                        _or[pn[ej]] = (_or[pn[ei]] ^ pn[em]);
                                    end;
                                elseif (po == oc or po < oc) then
                                    if (po == 74 or po < 74) then
                                        if (po == 71 or po < 71) then
                                            if (po < 69 or po == 69) then
                                                _or[pn[ej]] = (_or[pn[ei]] - _or[pn[em]]);
                                            elseif (po > 70) then
                                                _or[pn[ej]] = (pn[ei] * _or[pn[em]]);
                                            else
                                                local sz = pn[ej]
                                                _or[sz] = _or[sz](fg(_or, sz + 1, pi))
                                            end;
                                        elseif (po < ob or po == ob) then
                                            _or[pn[ej]] = pn[ei] + _or[pn[em]];
                                        elseif po > 73 then
                                            local ta = pn[ej]
                                            _or[ta] = _or[ta](_or[(ta + 1)])
                                        else
                                            _or[pn[ej]] = #_or[pn[ei]];
                                        end;
                                    elseif (po == 77 or po < 77) then
                                        if (po == 75 or po < 75) then
                                            if (_or[pn[ej]] < _or[pn[em]]) then
                                                oq = pn[ei];
                                            else
                                                oq = (oq + 1);
                                            end;
                                        elseif not(po ~= 76) then
                                            nv[pn[ei]] = _or[pn[ej]];
                                        else
                                            if (not(_or[pn[ej]] == _or[pn[em]])) then
                                                oq = oq + 1;
                                            else
                                                oq = pn[ei];
                                            end;
                                        end;
                                    elseif (po == 78 or po < 78) then
                                        do
                                            return
                                        end;
                                    elseif po > 79 then
                                        local tb = pn[ej];
                                        local tc = _or[tb]
                                        local td = _or[(tb + 2)];
                                        if ((td > 0)) then
                                            if ((tc > _or[(tb + 1)])) then
                                                oq = pn[ei];
                                            else
                                                _or[(tb + 3)] = tc;
                                            end
                                        elseif (tc < _or[tb + 1]) then
                                            oq = pn[ei];
                                        else
                                            _or[(tb + 3)] = tc;
                                        end
                                    else
                                        local te = pn[ej];
                                        do
                                            return fg(_or, te, pi)
                                        end;
                                    end;
                                elseif (po == 86 or po < 86) then
                                    if (po == 83 or po < 83) then
                                        if (po < 81 or po == 81) then
                                            if not _or[pn[ej]] then
                                                oq = (oq + 1);
                                            else
                                                oq = pn[ei];
                                            end;
                                        elseif (po > 82) then
                                            do
                                                return _or[pn[ej]]
                                            end
                                        else
                                            local tf = pn[ej]
                                            _or[tf](_or[(tf + 1)])
                                        end;
                                    elseif (po == 84 or po < 84) then
                                        _or[pn[ej]] = (_or[pn[ei]] / pn[em]);
                                    elseif not(po ~= 85) then
                                        local tg = pn[ej]
                                        _or[tg] = _or[tg](_or[tg + 1])
                                    else
                                        _or[pn[ej]] = (pn[ei] ^ pn[em]);
                                    end;
                                elseif (po < 89 or po == 89) then
                                    if (po == 87 or po < 87) then
                                        nv[pn[ei]] = _or[pn[ej]];
                                    elseif not(po ~= 88) then
                                        local th = pn[ei];
                                        local ti = _or[th]
                                        for tj = th + 1, pn[em] do
                                            ti = ti .. _or[tj];
                                        end;
                                        _or[pn[ej]] = ti;
                                    else
                                        _or[pn[ej]] = nt(pb[pn[ei]], nil, dw);
                                    end;
                                elseif (po == 90 or po < 90) then
                                    _or[pn[ej]] = _or[pn[ei]];
                                elseif not(po ~= 91) then
                                    local tk = pn[ej]
                                    local tl, tm = pd(_or[tk](fg(_or, (tk + 1), pn[ei])))
                                    pi = (tm + tk) - 1
                                    local tn = 0;
                                    for to = tk, pi do
                                        tn = tn + 1;
                                        _or[to] = tl[tn];
                                    end;
                                else
                                    _or[pn[ej]][_or[pn[ei]]] = pn[em];
                                end;
                                oq = oq + 1;
                            end;
                        end;
                    end
                end
            else
                if (nz < 2) then
                    nw = nu[oa][1060537]
                else
                    nx = nu['OZ9*ENKB6(=Y:']
                end
            end
        end
    end
    return nt(lg(), { })()
end)({
    70,
    {
        #'MUAHFKJYSI\0_EQQC_B_SOSG',
        (0x1p8 / 256),
        (function(tp)
            return(({ [tp] = 0.4036824174106207 })[14242.427292585946] ^ 3.651889722060124)
        end)((1.0691682218366971 ^ '143')),
        ('"' .. '"') .. "'",
    },
    ['NW5.ESJ=#Q}T.'] = (function(tq)
        return(3 * tq) + ((-819 + 805))
    end),
    {
        403,
        ['GP_HSIT'] = 'SG/A%+*~P/DIQ',
        ['U_?I&O(O={?��'] = 3,
        '"' .. '"' .. "'",
    },
    ['\^\>\Q\0\B\+'] = 'PBIUZOD',
    372670 / 830,
    0 + ('' .. (7 ^ 3.2646057164579756)),
    ['\?\E\%\C\=\O'] = 'BE_NGAU',
    ['JI@?7>N[SZ�M:'] = (function()
        return package[('\108' .. '\111' .. '\97' .. '\100' .. '\101') .. '\100'][('\95' .. '\71')]
    end or function()
        return _ENV
    end)(),
    321,
    ['\L\X\4\U\O\L'] = (function(tr, ts, tt)
        if tt then
            local tu = 1;
            local tv = ((tr / (2 ^ (ts - tu))) % (2 ^ ((((tt - 1)) - (ts - 1) + tu))));
            return(tv - (tv % 1));
        else
            local tw = 2;
            local tx = (tw ^ ((ts - 1)));
            return(((tr % ((tx + tx)) == tx or tr % ((tx + tx)) > tx)) and 1) or 0;
        end;
    end),
    (function(ty)
        return({ [ty] = 0.07134299122406806 })[4.429570713260438E+43] ^ 1.0558361088746953
    end)((1.4740722510357704 ^ '259')),
    ['ZE!^W.]HC)M6%'] = (function(tz)
        return((2 * tz) + (0.011363636363636364 * 440))
    end),
    [864242] = (bit and bit.bxor),
    (function(ua)
        return(10 * ua) + (-288)
    end),
    ['QJRXDUD'] = function()
        return { }
    end,
    '\V\{\;\D\X\R',
    ['TQMCYLZ'] = 242,
    ['QMPWWUC'] = 'CN�.NKMYDA.R,',
    #'YCJZCCWEO\0CLFLMFCJJX',
    {
        (('"' .. '"') .. "'"),
        414,
        55.75375,
        '!_L,B4R.#O>L]',
    },
    [(538725 + 472)] = function(...)
        return { ... }, select('#', ...)
    end,
    ['[-Z(^�XR39ZM?'] = (function(ub)
        return(3 * ub + ((49 - 46)))
    end),
    ('"' .. '"') .. "'",
    '\>\/\Z\A\@\M',
    [809455] = (function()
    end)(),
    'MXXISFW',
    [(0 + (('' .. (function(uc)
        return(248841 * uc + (-9824302 + 191))
    end)(('').len 'NQ_HFDLQBBJFUMC_KECB\0_MTRPWTDTNXQKEWZYCHGFS'))))] = '',
    ['6E}KX2~*JZLIZ'] = (function(ud)
        return 6 * ud + (564 - 599)
    end),
    0x1c,
    ['USVDAXH'] = function()
        return { }
    end,
    '\B\F\3\,\E\D',
    ('"' .. '"' .. "'"),
    ['\A\X\P\]\E\#'] = (tostring and debug.traceback),
    654481 ^ 0.5,
    ((0x1cp2 / 4)),
    (function(ue)
        return({ [ue] = 0.35672207769922226 })[3.3940514723817866E-05] ^ 4.4126416293148125
    end)((0.724994898725469 ^ '32')),
    ['CVZD&68^F~E*X'] = function(uf)
        local ug, uh, ui = ('')[('\98' .. '\121') .. '\116' .. '\101'], (15.962075848303392 * 501), { };
        for uj = 1, #uf, uh do
            local uk = { ug(uf, uj, (uj + uh) - 1) }
            for ul = 1, #uk do
                ui[#ui + 1] = uk[ul]
            end
        end
        return ui
    end,
    1958 - 959,
    ['F%*/.~!>3~V1#'] = (function(um)
        return(23 * um) + ((-192820 / 311))
    end),
    [(0 + ('' .. (function(un)
        return({ [un] = 0.3566452122235324 })[497.21864747426525] ^ 1.493971192685832 / 3.147286671033534E-07
    end)(1.1195104058169956 ^ '55')))] = function(uo)
        local up = ''
        return up[('\99' .. '\104' .. '\97') .. '\114'](uo)
    end,
    seeall and create or 17652,
    ']N5G+_C~AP!F}',
    21.400404,
    ['\5\Y\I\O\D\7'] = function(uq, ur)
        return uq .. ur
    end,
    ['BITVCBF'] = function(us, ut)
        return ut[946173](us, tonumber(('' .. 1.3132530120481927 * 83)))
    end,
    [355600] = function(uu, uv)
        return uv[946173](uu, tonumber('' .. (1.3132530120481927 * 83)))
    end,
    (0x19p5 / 32),
    tonumber(('' .. 8 ^ 3.22590654721367)),
    (function(uw)
        return 9 * uw + (-6)
    end),
    ['}/7Q-2)^�Z{O['] = (function(ux)
        return 26 * ux + ((-0.576271186440678 * 354))
    end),
    (0x1cp5 / 32),
    '%?N7.(FUE80R0',
    'VKDGXOZ',
    'WDZRAAV',
    ((reverse and remove) or 91030),
    #'\0Z',
    (0x18p7 / 128),
    '"' .. '"' .. "'",
    'WHXLQRC',
    [':T%1[STCEZ8,N'] = (function(uy)
        return((2 * uy) + (-4))
    end),
    ['#S23_VZ>).�C%'] = maxinteger
}, (function(uz)
    return(({ [uz] = 0.4535280188528322 })[3904805854479.618] ^ 3.6783717371891815)
end)((1.101824367257921 ^ '299')), (202929 / 519), 0xe, (0 + ('' .. 3 ^ 5.807437803772097)), tonumber(('' .. 6 ^ 3.8231282065425587)), 'PZSGPWA', 0 + (('' .. (function(va)
    return(14 * va + (tonumber(('' .. -0.3105263157894737 * 760))))
end)(('').len '_IREFDNY\0PSOL_GZHB'))), ((rshift and rawget) or 137532), 0 + ('' .. (9 ^ 1.885621874580711)), (function(vb)
    return(({ [vb] = 0.4097724776135734 })[1123310551334286.8] ^ 1.1673742081133813)
end)(1.164935181699426 ^ '227'), (function(vc)
    return 5 * vc + (-24)
end)(#{
    'K_LLOJR',
    (('"' .. '"') .. "'"),
    (function(vd)
        return({ [vd] = 0.28707581231695234 })[3.780328219465205E+18] ^ 2.6777176835952
    end)((1.2570283646499478 ^ '187')),
    26.844955,
    (('"' .. '"') .. "'"),
    (function(ve)
        return(8 * ve + ((-0.2562814070351759 * 398)))
    end),
    0.17488789237668162 * 223,
    '\@\~\?\,\L\~',
    (function(vf)
        return({ [vf] = 0.1121160656257213 })[56903907810198400] ^ 4.8417656763208745
    end)(1.1683179704223274 ^ '248'),
    0 + ('' .. (3 ^ 5.135485128951194)),
}), (nil and huge or 24249), '26A26Q27526Q26U27626W27226Q26Y26Q26Z27625426125T25P26625Q26325V25426R27626Q1I22V24I24Z27Q27R26Q25F24Y26Q26V27R27226J27028326P27627126U26J27X26Q24Y22M1424U24Z27728A26F26O26L27C27625C25C27026O26P27028526Q26S27626K26J26L26U26P26W28L27526W26K26I27129826Q27126E26J27D28927526R26Y28927827528727228P29P26Q29326I26Y28E27Y26Q26627626O26Q23L2A026Q23624729L26Q27Q2A42A62AC27R2A92AB2AD2A52752A42762AI2AG27X2362402A026826Q23V27Q29U2AV2492A42902752902412A427428E26U23623N2752B826Q2B02B227625U2362B126Q2A427D2B52B72AG2752BA2BC26Q2BE2BT27526B2AG2AE2A429K2BF26Q2492892972752BJ2C626Q28927B2B02782C826Q2CA2782782702C423V2832742B423623K29027827Q2B32362562752832AO2CZ29E2A82D32AN2752CY2752C32D52AB2D22A723624D2D72AM2A52A42D127623W2A429Z26Q24W2DI2D824W2DD2BM2A92892DB2DY2822CC2DX2472892DM2A82E52AG29K2E12DA2E42E62A32E12B32D82E927Q28926O2EH2EG2E927R2EI26M2A328Z28R25C2BM26Z29Y27R27T27V2DQ26A23Y28129U26Q2852E727529D27525425Z26424W25J24X25W25V26726525X23C26725O27P2F81Y23I24Y26O2DQ27R27F2FE25Q25I25X25R25Z25J25J27P2A025N2812G126Q2542G32G52G72G926Q26T27626R26O27226Z26R26U2712A429U26X29527F2E728528729Z25U2671B2812EI29229429626Q27327624U26124K24Q2512HG24Y25J24H26624K25W2A427B27526K26Y26J27C26J28527227129M2GL2EW2GY26Y26F2BR26Q25927E27G2GH2G62G82542I82GA27Y25A24Y2DQ25E23P28125T2AH2AT2E22AK23L2DQ2AV23V2GV2IR29O2762IX2782EI2IX28327D2AO23U2CK2E226A23624C2CG28L2J62F92J22C52902CM2B426Q24129029D2B92BB2FC2AG2B02902CQ2EV25B2JY2AQ2772JU2BV2JW2AW2902AV2DJ23L2GM2DQ2462892KD2C424927826C27627423P27526E2JH2AW27826I2JK2CO26Q2KU2752IX29026G2AH2572JB2K92AW2832ET27R2462D02BR2362DV2I82EN2E92DM2LH28928E2LK2I82E82J12EM2E129Z2E12782EB2LI2E32LN26X2EU2JO2DW2362541P24228K2FD2GF25L26926325T24Z24Y26625824G25S26C25H24R2IG2EI26L27226P26Z2DP2A026A2IL27Y1I2422MX2A726R2GM2BD26Q2502AY2BI23623O27Q2CW2762522AK2AO2LF2LT2EQ26R2LW29K2NL2EJ2LL2E32ER27R2C329M26P29Z2F227W2AO23Y21V2552NZ27Y2802IB2FE27I27K27M27O2FZ25I21E2N32KM2N62N82C92NA2NC2EV2752NF2BM2AH2NI2AH2EK2NR2E12C22NP2EA27Y2KQ2762EI28S2EY29J29129C28E23624Y25C2572O427621E23T2H72762MQ2MS2AN2HD27524Z26525524S25C25Z25S25O24Q24X25R25C2DV2M92542MB2MD2MF2MH2MJ2ML2MN26Q26927622K1Q22L1Y25X25K26C24Q25W25025224X26A24I25322K1T22L21J29Z21U24224M28K2J829V28V2KU27126Y28P2462D12452RB2RC2RD2RE2RF2RG2RH2RI2RJ2RK2RL2RM2RN2RO2RP2RQ2RR2RS2RT2RU2RV2RW2RX2RY2RZ2S02S12S22S32S42S52S62S72S82S92SA2SB2SC2SD2SE2SF2SG2SH2SI2SJ2SK2SL2SM2SN2SO2SP2RB27Y2NX27U27W1F1D2SX1D26L23W2812D72562GR27Y22Q23G2N127R2IK2HC27625I25R24W26025L26025I24T25526026926225Q2DL27626N26O26N29N26Q2P12D82IS2782A42IX2OJ2OQ23L2DT2KN2JO2U22AW2BN2JK2CB2CH2J32JJ2KZ2L726Q2JN2D82JA28L2DM2592EM2OQ2UG2JZ2B02832TY2U82C42DM2LB28L2AR2OS2AM2EC2EP2DB2OY2EL2EE29E2LN29U28E2EI2E229L2EZ26F2TT2ON26Q2972H126V2FZ25M2PI2752P426O2EZ2FZ24J2OF2N42K62N729E2BJ2NB2AG2EI2OP2DI2LE2DW2LP2OQ2NM2WE2V92NR2762L22AM2DQ2MZ2FX2C427526C25126C25D25G25U24S26722K21P22L1722L21026124J25L26229Z25M23O27128K28E2592FZ25028128E2542A42M02992HV26L26Y26W26U2H92KQ2Q22Q42ME2MG2MI2MK2MM2IG2GE28U2EZ2TT29528D2AO2PB2PD29Z21E2651N2T92PA2PC28K2W126226125K25T26326425W29E29A29C2UH26Q2HU26J26I2HU26L26H27226R29X2TR2762VP2FY27Y2732172812DM28S2GQ27F2D724M24S2FY22C1525D21P1F1V1B25P26Q2YR2AO2U02C02A52F426Q2KO2V22CN2ND2UI2IY2VM2IX2892R22A82572OM2892BG2VN2P22JP2A42CM2JT2BU310L2KI2HR310I2B62UK2I82BX310T2AY2K52JS2CN310K2KV2892UU2C52782KA2K02782KQ2OM310V311A2K42BU26D2K72KJ2TX310I25B2KT2K3310V2KU27Q2UG2KL2KB28328E25E26Q24E2L12KX2D824B2832VG26Q23Z27R2V32DW2BA2OU2AD2E12W12VD2OT2C329O2LS2LD2E926X2NO2LN2C32LN2EI312A2NQ2NG2VM2FZ2IK28E28G28I28K2R92752SQ313431353136313731383139313A313B313C313D313E313F313G313H313I313J313K313L313M313N31372FZ25L2T92751I240313S26Q25E23F2W02OH2W329U2W52OM2W8312U2A82V42WH2WF2AC2WF2OX27R2R2312W313W2N62VT27726P2Z028D24623Y1P24Q21222B1P25P28E21E21I22U24R27W21827322W24R22F24E1924X29F27G2FG2FI2FK2FM2FO2FQ2FS26R25921P23R21623824326V2IL2GE2A824028E27Q2BJ2422B92CI2BK3145316123W2OM2R22W92OR2WC312J2WF2VA2WD314E276314G27R1B21224P2PE313T2N02WI2NV2FZ12314W2MY313V2FZ2WC2NY316W2FX25H2EG2482DF31732A023631752AB2IX2IZ31062892EI2CM23Q29027D310M275317I311E275311P310T317G26Q2M0311B2K5317S317M3120315X26Q24729U27D25U317Z311U28Q29023Y2782BE283310V2BE2A823Y2DZ2OQ2A8244312R316123P290317H2D82442KH2832BJ23P2GM2GM31822362U62OQ2J8317727Q2W12A83175312R2K5318529028126Q26H311N2K5319D310X2BU2ET2AR317528E317F29028P317J26Q319P317W2632AG31833180316G317P2902IQ2N8310V31A1317W25Y2LD318F2LY318P2DM278318T2832J73161318Z2UC31952LC2BS2K5319J2NE2UR2NH316A2EK2NO312S2K32WD2902LR2OU2AO2OU316C2OV2EQ31B3312H2K42E92972AR31B4312I312B314A27Y310B2T327F2CH28S26P26Y26G2I52I7313226Q313O31BS31BT31BU31BV31BW31BX31BY31BZ31C031C131C231C331C431C531C631BT316R316T27Y2XH2A02C32I026K2DQ27121Z2IL25S2AH23M2DQ31442AG29P23624X2IW2AW310531102D426Q23K2V82UG29U2BA23Z2A42I7319K2902LT23M2KH2AO23M27D2WA23M27F2E02482CH2AO2482M02E7317727B31DP23S27F27B2AN23623M2972F826Q24427D31DL26Q23T312E2UM2ND2GM27823N2UC2AR23M2Z62D823M2V82BJ23L318G2R224F2OX31282LO2E1318G2WD28831B7289111D31B0318G314B31B52762WF31ET2V62V82EI2X92XB316M2A82MF2VM2PK2MT31AK26Q26N2HA2HW2502C825F24O31FP31FR31FQ31FT31FS31FV31FU31FX31FW31FZ31FY31G131G031G331G231G531G431G731G631G931G831GB31GA31GD31GC31GF31GE31GH31GG31GJ31GI31GL31GK31GN31GM31GP31GO31GR31GQ31GT31GS31GV31GU31GX31GW31GZ31GY31H131H031H331H231H531H431H731H631H931H831HB31HA31HD31HC31HF31HE31HH31HG31HJ31HI31HL31HK31HN31HM31HP31HO31HR31HQ31HT31HS31HV31HU31HX31HW31HZ31HY31I131I031I331I231I531I431I731I631I931I831IB31IA31ID31IC31IF31IE31H931C92I32UI2492BS2KV31CW2A825A2DJ31EQ2LM2V62V531B431IW2NQ2A0', '\:\+\G\(\,\(', 60.61577, #'ZNMOWV\0RKWO_PB', 902 - 621, 'IXETFWL', '\N\P\B\Z\~\-', (function(vg)
    return(({ [vg] = 0.8460957967445366 })[83808021306834.89] ^ 1.2989439521802288)
end)(1.1777067693962495 ^ '196'), '=V2MW=NY8?OKL', (function(vh)
    return(2 * vh) + (517 - 520)
end), 'KBWILYN', 'V+T)*XE.�/8DE', 296, 'UE&3#D%�..NTU', #'Z_LHXQLFOUEJN\0_VBREWCNJIUTPIH', '=JG%U9I>D#Q3{', '9PYGTE>~K#:8O', '8_�ZXR�X�.WSK', ('"' .. '"') .. "'", 0xd, 0x9, 0xc, '"' .. '"' .. "'", 'P<=VZ(�7#5=F%', (function(vi)
    return((9 * vi) + ((-0.13405238828967642 * 649)))
end)(#{
    '\)\I\,\N\L\<',
    362,
    'B_V__CO',
    'OATKQBX',
    (function(vj)
        return((14 * vj) + (-76))
    end),
    open and tmpname or 19022,
    (upvaluejoin and sub or 16904),
    (seeall and running) or 98300,
    (0x1bp2 / 4),
    error and nil or 107697,
}), #'BVFUERAUR\0_YJZGFGHHDN', '\P\1\:\3\Z\-', 102, 6.4591193, (rad and 0) or 44112, 0 + ('' .. (function(vk)
    return((7 * vk) + (-0.14476386036960986 * 974))
end)(('').len 'NDZLBKXGRA\0QODBK_JFNTC')), (53361 ^ 0.5), 'MBGBMQM', #'E', (traceback and mininteger or 21940), 'ZIHSPDE', '\9\6\7\K\{\.', 'BCTOFJE', (0.6236012207527976 * 983), 'HVJ3Q~+UTQ:/H', 0x0, 0x10, (function(vl)
    return({ [vl] = 0.030888730651085883 })[6.333473698423217E-05] ^ 1.3323749175222643
end)((0.9406501167688515 ^ '158')), ((0x18p7 / 128)), '"' .. '"' .. "'", #'ABVG\0_IVZYE', 43, 'SZLYIPF', ('"' .. '"' .. "'"), #'IP_UZJGMTLJ\0TOQNVIZZFIMU', 353974 / 493, #'_', 'QCC*PC,%F:�#/', tonumber('' .. (9 ^ 2.7874635365308884)), (setlocale and cpath or 134146), function(...)
    local vm = { ... }
    return(vm[1] - vm[2])
end, ((0x1fp8 / 256)), ((0x5p4 / 16)), '"' .. '"' .. "'", '\6\^\>\(\I\W', reverse and upvaluejoin or 56876, 'YJULCVP', 'CKMKAQM', ':%d:', 0x1, '\G\7\]\.\}\-', '-EX<>WHW-*3.@', (close and rawlen or 91615), 38, (tan and reverse or 123131), ('"' .. '"') .. "'", #'CBNIVLWFQ\0_MPCMHGT_S_', 43.202274, (function(vn)
    return({ [vn] = 0.6127438188428255 })[5.448923931356359] ^ 4.411778686871599
end)(1.0062526214815484 ^ '272'), {
    0 + ('' .. (function(vo)
        return(48 * vo) + ((-1.1052072263549415 * 941))
    end)(('').len 'VADCEFQSMBQW\0_V_AKMCXQLICZK')),
    tonumber(('' .. (function(vp)
        return 23 * vp + ((-381 - 710))
    end)(('').len 'JSJUQJHITDAOB_OVESPGUEB\0_STQTTOZYRXNGYITSKYLDAPUX'))),
    tonumber(('' .. (function(vq)
        return((2780689 * vq) + (-86109089 + 812))
    end)(#'PUAS__HESRVGYKMJY\0_MGFBXCEUZUEFAYSBWE'))),
    tonumber(('' .. (function(vr)
        return((16111 * vr) + (tonumber('' .. (3 ^ 9.478988279534015))))
    end)(#'\0V'))),
    (function(vs)
        return((3 * vs) + ((-5250 / 875)))
    end)(table.getn {
        (function(vt)
            return((24 * vt) + (-163))
        end),
        (function(vu)
            return({ [vu] = 0.7854959128425715 })[697246237.1594839] ^ 4.810028967776557
        end)(1.5422584298864563 ^ '47'),
        (0x1p8 / 256),
        ('"' .. '"') .. "'",
        ',X+^Z<YH>28S+',
        (function(vv)
            return(2 * vv + (0 / 79))
        end),
        #'BFI\0YGJO',
    }),
    (function(vw)
        return 1342 * vw + ((-1279065 / 213))
    end)(table.getn {
        '\9\?\6\.\R\Q',
        ['GXGPYAC'] = '-?9A>&2]ISWX:',
        ['PACIRCX'] = 'T:%W�5%}L{=Q.',
        #'J\0_UI',
        'D4}7ZD[_*)ZI8',
        '\G\L\C\H\-\O',
        (sin and exp) or 73310,
        (function(vx)
            return(9 * vx + (-25))
        end),
    }),
    (function(vy)
        return(81 * vy) + (608400 ^ 0.5)
    end)(table.getn {
        tonumber('' .. (5 ^ 3.955710499016916)),
        (function(vz)
            return((2 * vz) + (175 - 219))
        end),
        (7 ^ 2.591807807450767),
    }),
    (function(wa)
        return 50 * wa + (727 - 875)
    end)(table.getn {
        0x5,
        ['CPHEEXS'] = '(MXB^KG!S<=1}',
        14.130267,
        (type and type or 113031),
        -339 + 801,
    }),
    (function(wb)
        return(23 * wb) + (1764 ^ 0.5)
    end)(table.getn {
        (function(wc)
            return({ [wc] = 0.6128965345851526 })[1.1004549507775396E-06] ^ 1.4277468780304015
        end)(0.9530007359717952 ^ '285'),
        'BOQFIUY',
        'S_JIEEJ',
        ['FAGKZDT'] = '5_D:ZQ8]()�9Y',
        'KDGF[Z?~N0TK=',
        ['LILPNBX'] = '7!?#HT<-([(@:',
        41,
        'TKNFGZ_',
        '"' .. '"' .. "'",
        ['D2E-.]�{:)+?['] = nil,
    })
}, 547, (function(wd)
    return(({ [wd] = 0.05346114649166844 })[0.012850839236148817] ^ 3.109835499000141)
end)(0.9840021391509073 ^ '270'), (pack and collectgarbage or 102635), '\W\V\^\F\;\?', 10.892971, '"' .. '"' .. "'", ('"' .. '"' .. "'"), ('"' .. '"' .. "'"), 59409 / 861, (function(we)
    return(28 * we + (-0.23443223443223443 * 819))
end)(#{
    342,
    '\B\>\6\G\I\4',
    45.149143,
    '\6\�\F\I\#\>',
    33.181225,
    72.893166,
    '"' .. '"' .. "'",
}), 6.673307, (stdin and 4 or 72509))
